<?php



$host = 'localhost';
$user = 'jsonUsers';
$pass = 'password';
$db = 'jsonDataBase';
$mysqli = new mysqli($host,$user,$pass,$db);
    
    if(!$mysqli){
    
    die('error connecting to Database');
}
//echo"Very Successful Connection";

$url = 'http://bandungtourism.com/data/json/data-ttd.php';
$json = file_get_contents($url);
$data = json_decode($json,true);

//echo "<table border=1>";
//    echo "<tr>
//      <th>No.</th>
//      <th>ID</th>
//      <th>kategori</th>
//      <th>Name</th>
//      </tr>";
//        
//        for($i=0; $i<98; $i++){
//            
//            $row = $data['ttd'][$i];
//            $no = $i+1;
//            
//            echo "<tr>
//            <td>$no</td>
//            <td>$row[id]</td>
//            <td>$row[kategori]</td>
//            <td>$row[nama]</td>
//            </tr>";
//        }
//
//echo "</table>";


//$stmt = $mysqli->prepare("insert into jsonTable values(?,?,?,?)");

foreach($data as $row){
    
//    $stmt->bindParam(1, $row['id']);
//    $stmt->bindParam(2, $row['number']);
//    $stmt->bindParam(3, $row['category']);
//    $stmt->bindParam(4, $row['name']);
//    $stmt->execute();
    
    //$sql = "INSERT INTO dataTable(number, category, name) VALUES ('".$row["id"]."','".$row["kategori"]."', '".$row["nama"]."')";
    for($i=0; $i<98; $i++){
            
            $row = $data['ttd'][$i];
    
    $sql = "INSERT INTO dataTable(number, category, name) VALUES ('".$row["id"]."', '".$row["kategori"]."', '".$row["nama"]."') ";
    
    mysqli_query($mysqli,$sql);
    }
}

echo "Data Inserted";



//var_dump($data);

//echo $data['ttd'][50]['kategori']


?>